/*
Name - Erik W. Failing
Username - efailing
Assignment 1
*/

#include "pch.h"
#include "DateType.h"
#include "TestDriver.h"
#include "User.h"
#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <cmath>
#include <string>
#include <fstream>
#include <math.h>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <limits>
#include <vector>
#include <tuple>
#include <map>
#include <iterator>
#include <algorithm>

using namespace std;

int main()
{
	TestDriver test;
	ofstream outFile;
	User users[100];
	char input[300];
	int count = 0;

	//Assign input
	strcpy(input, "C:\\Users\\Erik\\OneDrive\\Documents\\UAH\\DataStructures\\HW1\\hw1samplefile.txt");

	//Test to console
	count = test.Populate(input, users);
	test.Test(users, count);

	//Open outfile
	outFile.open("C:\\Users\\Erik\\OneDrive\\Documents\\UAH\\DataStructures\\HW1\\efailingHw1Outfile.txt");
	if (!outFile)
	{
		cout << "Can't open file." << endl;
		return 1;
	}

	//Test to file
	test.Test(outFile, users, count);

	outFile.close();

	return 0;
}
